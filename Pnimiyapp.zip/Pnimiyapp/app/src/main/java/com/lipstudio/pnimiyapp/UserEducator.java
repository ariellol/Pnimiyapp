package com.lipstudio.pnimiyapp;

import java.util.ArrayList;

public class UserEducator extends User{


    public UserEducator(String firstName, String lastName, long id, String password, String mail, ArrayList<String> groups){
        super(firstName,lastName,id,password,mail,groups);
    }

}
