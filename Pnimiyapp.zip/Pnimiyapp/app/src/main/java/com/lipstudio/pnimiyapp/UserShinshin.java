package com.lipstudio.pnimiyapp;

import java.util.ArrayList;

public class UserShinshin extends User{


    public UserShinshin(String firstName, String lastName, long id, String password, String mail, ArrayList<String> group){
        super(firstName,lastName,id,password,mail, group);
    }

}
